import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';

function Restaurant() {
  return (
    <group position={[0, 0, 0]}>
      {/* Building base */}
      <mesh position={[0, 0, 0]}>
        <boxGeometry args={[4, 0.2, 3]} />
        <meshStandardMaterial color="#c0c0c0" />
      </mesh>
      
      {/* Main building */}
      <mesh position={[0, 1.5, 0]}>
        <boxGeometry args={[3, 3, 2]} />
        <meshStandardMaterial color="#f5f5f5" />
      </mesh>
      
      {/* Roof */}
      <mesh position={[0, 3, 0]} rotation={[0, 0, 0]}>
        <coneGeometry args={[2.5, 1, 4]} />
        <meshStandardMaterial color="#8b4513" />
      </mesh>
      
      {/* Door */}
      <mesh position={[0, 1, 1.01]}>
        <boxGeometry args={[0.8, 2, 0.1]} />
        <meshStandardMaterial color="#8b4513" />
      </mesh>
      
      {/* Windows */}
      <mesh position={[-1, 1.5, 1.01]}>
        <boxGeometry args={[0.6, 0.6, 0.1]} />
        <meshStandardMaterial color="#87ceeb" />
      </mesh>
      <mesh position={[1, 1.5, 1.01]}>
        <boxGeometry args={[0.6, 0.6, 0.1]} />
        <meshStandardMaterial color="#87ceeb" />
      </mesh>
      
      {/* Tables */}
      {[[-1, 0.2, 0], [1, 0.2, 0]].map((position, index) => (
        <group key={index} position={position}>
          <mesh position={[0, 0.3, 0]}>
            <cylinderGeometry args={[0.3, 0.3, 0.05, 16]} />
            <meshStandardMaterial color="#8b4513" />
          </mesh>
          <mesh position={[0, 0, 0]}>
            <cylinderGeometry args={[0.1, 0.1, 0.6, 8]} />
            <meshStandardMaterial color="#8b4513" />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Restaurant3D() {
  return (
    <div className="h-[500px] w-full bg-gray-100 rounded-lg shadow-lg overflow-hidden">
      <Canvas 
        camera={{ 
          position: [6, 4, 6], 
          fov: 50 
        }}
        shadows
      >
        <Environment preset="sunset" />
        <ambientLight intensity={0.5} />
        <directionalLight
          position={[5, 5, 5]}
          intensity={1}
          castShadow
        />
        <Suspense fallback={null}>
          <Restaurant />
        </Suspense>
        <OrbitControls 
          enableZoom={true} 
          enablePan={true}
          minPolarAngle={Math.PI / 4}
          maxPolarAngle={Math.PI / 2}
        />
      </Canvas>
    </div>
  );
}

export default Restaurant3D;