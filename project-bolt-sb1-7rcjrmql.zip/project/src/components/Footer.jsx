import React from 'react';

function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Gourmet 3D</h3>
            <p className="text-gray-300">
              Experience fine dining in a whole new dimension
            </p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Hours</h3>
            <p className="text-gray-300">Mon-Fri: 11am - 10pm</p>
            <p className="text-gray-300">Sat-Sun: 10am - 11pm</p>
          </div>
          <div>
            <h3 className="text-xl font-bold mb-4">Contact</h3>
            <p className="text-gray-300">Phone: (555) 123-4567</p>
            <p className="text-gray-300">Email: info@gourmet3d.com</p>
          </div>
        </div>
        <div className="mt-8 text-center text-gray-400">
          <p>&copy; 2023 Gourmet 3D. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;