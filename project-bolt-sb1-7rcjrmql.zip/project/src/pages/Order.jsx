import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { sendOrderEmail } from '../utils/emailService';

function Order() {
  const [order, setOrder] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [loading, setLoading] = useState(false);

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window)) {
      alert('Voice recognition is not supported in your browser');
      return;
    }

    const recognition = new webkitSpeechRecognition();
    recognition.lang = selectedLanguage;
    recognition.continuous = false;
    recognition.interimResults = false;
    
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setOrder(transcript);
    };

    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
      setIsListening(false);
    };

    recognition.start();
    setIsListening(true);

    recognition.onend = () => {
      setIsListening(false);
    };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      await sendOrderEmail(order);
      alert('Order placed successfully!');
      setOrder('');
    } catch (error) {
      alert('Failed to place order. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <motion.h2 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-3xl font-bold text-center mb-8"
      >
        Place Your Order
      </motion.h2>
      
      <div className="mb-6">
        <label className="block text-gray-700 mb-2">Select Language:</label>
        <select
          value={selectedLanguage}
          onChange={(e) => setSelectedLanguage(e.target.value)}
          className="w-full p-2 border rounded"
        >
          <option value="en-US">English</option>
          <option value="es-ES">Spanish</option>
          <option value="fr-FR">French</option>
          <option value="de-DE">German</option>
          <option value="it-IT">Italian</option>
          <option value="ja-JP">Japanese</option>
        </select>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-gray-700 mb-2">Your Order:</label>
          <textarea
            value={order}
            onChange={(e) => setOrder(e.target.value)}
            className="w-full p-2 border rounded h-32 resize-none"
            placeholder="Enter your order or use voice input"
            required
          />
        </div>

        <div className="flex space-x-4">
          <motion.button
            type="button"
            onClick={startListening}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`${
              isListening ? 'bg-red-500' : 'bg-blue-500'
            } text-white px-4 py-2 rounded hover:bg-blue-600 transition`}
            disabled={loading}
          >
            {isListening ? 'Listening...' : 'Start Voice Input'}
          </motion.button>
          
          <motion.button
            type="submit"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition"
            disabled={loading || !order.trim()}
          >
            {loading ? 'Placing Order...' : 'Place Order'}
          </motion.button>
        </div>
      </form>
    </div>
  );
}

export default Order;