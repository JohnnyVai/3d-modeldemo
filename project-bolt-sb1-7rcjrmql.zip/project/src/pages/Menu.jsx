import React from 'react';
import { motion } from 'framer-motion';

const menuItems = [
  {
    id: 1,
    name: 'Signature Pasta',
    description: 'Fresh homemade pasta with truffle sauce',
    price: 24.99,
    category: 'Main Course'
  },
  {
    id: 2,
    name: 'Grilled Salmon',
    description: 'Atlantic salmon with herbs and lemon',
    price: 29.99,
    category: 'Main Course'
  },
  {
    id: 3,
    name: 'Chocolate Fondant',
    description: 'Warm chocolate cake with vanilla ice cream',
    price: 12.99,
    category: 'Dessert'
  }
];

function Menu() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-center mb-8">Our Menu</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menuItems.map((item) => (
          <motion.div
            key={item.id}
            whileHover={{ scale: 1.05 }}
            className="bg-white rounded-lg shadow-md p-6"
          >
            <h3 className="text-xl font-semibold mb-2">{item.name}</h3>
            <p className="text-gray-600 mb-4">{item.description}</p>
            <p className="text-lg font-bold">${item.price}</p>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default Menu;