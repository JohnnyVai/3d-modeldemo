import emailjs from '@emailjs/browser';

// Default test configuration for development
const EMAIL_SERVICE_ID = import.meta.env.VITE_EMAIL_SERVICE_ID || 'default_service';
const EMAIL_TEMPLATE_ID = import.meta.env.VITE_EMAIL_TEMPLATE_ID || 'default_template';
const EMAIL_PUBLIC_KEY = import.meta.env.VITE_EMAIL_PUBLIC_KEY || 'default_key';

export const sendOrderEmail = async (orderDetails) => {
  if (EMAIL_SERVICE_ID === 'default_service') {
    console.warn('Email service not configured. Please set up EmailJS environment variables.');
    return { status: 'development', message: 'Email service not configured' };
  }

  try {
    const response = await emailjs.send(
      EMAIL_SERVICE_ID,
      EMAIL_TEMPLATE_ID,
      {
        to_email: 'johndhakaldai@gmail.com',
        order_details: orderDetails,
        timestamp: new Date().toISOString()
      },
      EMAIL_PUBLIC_KEY
    );
    return response;
  } catch (error) {
    console.error('Email sending failed:', error);
    throw error;
  }
};